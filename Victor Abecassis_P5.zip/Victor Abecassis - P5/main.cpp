/* EECS 211 - PROGRAM 5: WORKING WITH COMMAND LINE COMMANDS

BY: VICTOR ABECASSIS
DATE: 2/15/2012

*/

#include "definitions.h" 
#include "system_utilities.h"
#include <iostream>
#include <fstream>

using namespace std;


int main() {

	char cline[MAX_CMD_LINE_LENGTH];
	char *tklist[MAX_TOKENS_ON_A_LINE];
	int tokCount;
	int halt =0;

	ifstream infile;
	infile.open("p5input.txt", ios::in);

	if(!infile.is_open()) {
		cout<<"The File was not opened."<<endl;
		return 0;
	}

	void fillSystemCommandList();

	while(halt == 0) {

		memset(cline, 0 , MAX_CMD_LINE_LENGTH);
		infile.getline(cline, MAX_CMD_LINE_LENGTH);
		tokCount = parseCommandLine(cline,tklist);

		cout<<"There are "<<tokCount<<" tokens on the command line."<<endl;
		cout<<"\nBelow is a list of the tokens:\n"<<endl;
		for(int i=0; i<tokCount; i++) {
			char *str = tklist[i];
			cout<<"Token number "<<i+1<<" is: "<<str<<endl;
			cout<<"\n";
		}

		int tokCommand = getCommandNumber(tklist[0]);
		int test_convert = convertIntToValue(tklist[1]);

		switch(tokCommand) {
		case HALT:
			cout << "Command halt recognized." << endl;
			halt++;
			break;
		case STATUS:
			cout << "Command status recognized." << endl;
			cout<<"\nThe value of the second token is: "<<test_convert<<endl;
			break;
		case TIME_CLICK:
			cout << "Command time-click recognized." << endl;
			break;
		case CREATE_DEVICE:
			cout << "Command create-device recognized." << endl;
			break;
		case CREATE_EVENT:
			cout << "Command create-event recognized." << endl;
			break;
		case SET_DEVICE_VALUE:
			cout << "Command set-device-value recognized." << endl;
			break;
		case PROCESS_EVENTS:
			cout << "Command process-events recognized." << endl;
			break;
		case UNDEFINED_COMMAND:
			cout << "Command not recognized." << endl;
			break;
		}

		cout<<"\n============================";
		cout<<"\n============================\n"<<endl;

		for(int k=0; k<tokCount; k++) {
			free((void *)tklist[k]);
		}
	}

	infile.close();
	int close_program;
	cout<<"Enter 0 to exit the program"<<endl;
	cin>>close_program;
	return 0;
}